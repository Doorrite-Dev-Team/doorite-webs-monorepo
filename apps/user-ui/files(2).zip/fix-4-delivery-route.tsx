/**
 * Fix 4 — /delivery Route
 *
 * OPTION A (recommended): Create a real page that redirects to explore
 * with a "quick delivery" filter pre-applied.
 *
 * File: app/(home)/delivery/page.tsx  (NEW FILE)
 */

import { redirect } from "next/navigation";

/**
 * /delivery simply redirects to the explore page
 * pre-filtered by the "Fast Food / Snacks" cuisine which is the
 * closest proxy for quick delivery items already in the system.
 *
 * When you have a proper backend filter for delivery_time (e.g. <20min),
 * swap the redirect to: /explore?maxDeliveryTime=20
 */
export default function DeliveryPage() {
  redirect("/explore?cuisine=Fast+Food+%2F+Snacks");
}


// ─────────────────────────────────────────────────────────────────────────────


/**
 * OPTION B (alternative): Fix the category card href instead.
 *
 * File: constants/categories.ts
 *
 * Change:
 *
 *   {
 *     id: "quick-delivery",
 *     name: "Quick Delivery",
 *     icon: Zap,
 *     color: "bg-orange-50 text-orange-600 border-orange-100",
 *     description: "15 min delivery",
 *     href: "/delivery",                          // ← broken
 *   },
 *
 * To:
 *
 *   {
 *     id: "quick-delivery",
 *     name: "Quick Delivery",
 *     icon: Zap,
 *     color: "bg-orange-50 text-orange-600 border-orange-100",
 *     description: "15 min delivery",
 *     href: "/explore?cuisine=Fast+Food+%2F+Snacks",  // ← fixed
 *   },
 *
 * Option A is better long-term because it lets you add real logic later
 * (filtering by estimated delivery time) without touching the constants file.
 * Just create the page file and you're done.
 */
