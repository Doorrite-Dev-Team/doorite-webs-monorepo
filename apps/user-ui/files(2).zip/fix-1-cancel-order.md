# Fix 1 — Wire Cancel Order API

**File:** `components/orders/OrderTrackingClient.tsx`

Find this function (around line 437):

```ts
const cancelOrder = async () => {
  toast.success("Order cancelled");
  setShowCancelDialog(false);
};
```

Replace with:

```ts
const cancelOrder = async () => {
  setIsLoading(true);
  try {
    const result = await api.cancelOrder(activeOrder.id);
    if (!result.success) {
      toast.error(result.error || "Failed to cancel order");
      return;
    }
    toast.success("Order cancelled successfully");
    setShowCancelDialog(false);
    // Navigate back to orders list so the updated status is visible
    router.push("/order");
  } catch {
    toast.error("Something went wrong. Please try again.");
  } finally {
    setIsLoading(false);
    setShowCancelDialog(false);
  }
};
```

That's it. `api.cancelOrder` already exists in `actions/api.ts` and hits `PATCH /orders/:id/cancel`.
The `isLoading` state and `router` are already declared in the component.
