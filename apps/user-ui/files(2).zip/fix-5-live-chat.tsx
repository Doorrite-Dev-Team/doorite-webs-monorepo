/**
 * Fix 5 — Wire "Live chat" in the SupportCard
 *
 * File: components/orders/OrderTrackingClient.tsx
 *
 * The ChatDialog component is complete and already used inside RiderInfoCard.
 * The SupportCard at the bottom just needs to open it.
 * Three changes required in OrderTrackingClient.tsx:
 */


// ─── CHANGE 1: Add import at the top of the file ─────────────────────────────
// Add ChatDialog to the existing imports block.
// Find the line:
//   import RiderInfoCard from "@/components/orders/RiderInfoCard";
// Add directly below it:

import { ChatDialog } from "@/components/orders/ChatDialog";


// ─── CHANGE 2: Add chat state next to the existing useState declarations ──────
// Find this block (around line 350):
//
//   const [showCancelDialog, setShowCancelDialog] = React.useState(false);
//
// Add directly below it:

const [showChat, setShowChat] = React.useState(false);


// ─── CHANGE 3: Replace SupportCard definition ─────────────────────────────────
// Find the entire SupportCard function:
//
// function SupportCard() {
//   return (
//     <Card className="border-border bg-card shadow-sm">
//       <CardContent className="p-4">
//         <div className="mb-4 flex items-center gap-2">
//           <MessageCircle className="h-4.5 w-4.5 text-primary" />
//           <h3 className="text-sm font-semibold text-foreground">Support</h3>
//         </div>
//
//         <div className="grid gap-3 sm:grid-cols-2">
//           <a href="tel:+2348000000000">
//             <Button variant="outline" className="h-12 w-full rounded-2xl gap-2">
//               <Phone className="h-4 w-4" />
//               Call support
//             </Button>
//           </a>
//           <Button variant="outline" className="h-12 w-full rounded-2xl gap-2">
//             <MessageCircle className="h-4 w-4" />
//             Live chat
//           </Button>
//         </div>
//       </CardContent>
//     </Card>
//   );
// }
//
// Replace with:

function SupportCard({ onOpenChat }: { onOpenChat: () => void }) {
  return (
    <Card className="border-border bg-card shadow-sm">
      <CardContent className="p-4">
        <div className="mb-4 flex items-center gap-2">
          <MessageCircle className="h-4.5 w-4.5 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Support</h3>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <a href="tel:+2348000000000">
            <Button variant="outline" className="h-12 w-full rounded-2xl gap-2">
              <Phone className="h-4 w-4" />
              Call support
            </Button>
          </a>
          <Button
            variant="outline"
            className="h-12 w-full rounded-2xl gap-2"
            onClick={onOpenChat}
          >
            <MessageCircle className="h-4 w-4" />
            Live chat
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}


// ─── CHANGE 4: Pass onOpenChat to SupportCard in JSX ─────────────────────────
// Find where SupportCard is rendered in the return block:
//
//   <SupportCard />
//
// Replace with:

<SupportCard onOpenChat={() => setShowChat(true)} />


// ─── CHANGE 5: Add ChatDialog to the JSX, near the bottom ─────────────────────
// Find the PaymentVerificationDialog near the end of the return block:
//
//   <PaymentVerificationDialog ... />
//
// Add directly after it:

<ChatDialog
  open={showChat}
  onOpenChange={setShowChat}
  orderId={activeOrder.id}
  riderName={activeOrder.riderId ? undefined : "Support"}
/>
