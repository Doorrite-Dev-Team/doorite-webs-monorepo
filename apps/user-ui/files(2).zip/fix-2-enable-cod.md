# Fix 2 — Enable Cash on Delivery

Two files to change.

---

## 2a. `services/payment-service.ts`

Find:

```ts
// Check if payment method is available (COD disabled for now)
static isPaymentMethodAvailable(method: BackendPaymentMethod): boolean {
  // Only card payment is available for now
  return method === "PAYSTACK";
}
```

Replace with:

```ts
// All payment methods are available
static isPaymentMethodAvailable(method: BackendPaymentMethod): boolean {
  return method === "PAYSTACK" || method === "CASH_ON_DELIVERY";
}
```

---

## 2b. `app/(home)/checkout/payment/page.tsx`

Find the COD `PaymentOption` block:

```tsx
<PaymentOption
  id="CASH_ON_DELIVERY"
  icon={<Banknote className="w-5 h-5" />}
  title="Cash on delivery"
  description="Pay when your order arrives"
  badge={{ label: "Unavailable", variant: "outline" }}
  selected={checkout.paymentMethod === "CASH_ON_DELIVERY"}
  disabled
  onSelect={() => {}}
/>
```

Replace with:

```tsx
<PaymentOption
  id="CASH_ON_DELIVERY"
  icon={<Banknote className="w-5 h-5" />}
  title="Cash on delivery"
  description="Pay in cash when your order arrives"
  selected={checkout.paymentMethod === "CASH_ON_DELIVERY"}
  onSelect={() =>
    setCheckout((s) => ({ ...s, paymentMethod: "CASH_ON_DELIVERY" }))
  }
/>
```

Note: Remove `disabled` and the `badge` prop entirely, and wire `onSelect` properly.

The `handlePlaceOrder` function already handles `ORDER_PLACED_COD` — it shows the success dialog and
redirects to the order tracking page. No further changes needed there.
